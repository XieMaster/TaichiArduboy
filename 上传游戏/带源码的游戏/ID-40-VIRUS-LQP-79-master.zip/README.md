# VIRUS LQP-79
![Image](http://www.team-arg.org/masterfiles/team-arg-vlqp/images/banner-ID-40.png)

VIRUS LQP-79 : http://www.team-arg.org/vlqp-manual.html  
**Download latest Arduboy version and source :** https://github.com/TEAMarg/ID-40-VIRUS-LQP-79/releases/latest  
MADE by TEAM a.r.g. : http://www.team-arg.org/more-about.html

2016 - FUOPY - JO3RI - STG - CASTPIXEL - JUSTIN CRY

Thanks to MLXXXp for his help on switching from ARGlib to the Arduboy 2 library

Game License: MIT : https://opensource.org/licenses/MIT
