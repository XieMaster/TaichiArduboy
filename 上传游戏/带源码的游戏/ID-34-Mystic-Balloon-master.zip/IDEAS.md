# ideas on Mystic Balloon

## gameplay ideas
- Sprint - Double tap a direction to run faster in that direction
- how do you get a new balloon? sucking in enemies ?
- shouldn't we need 3 balloons, 3 balloons pop = death

## game elements ideas
- coins with extra points: 5 coins to collect in each level
- power ups?
    - maybe the sprint idea, so it is only temporary
    - invincibility
    - jump higher
    - helium balloons, keep floating upwards (hidden treasure zones)

## level ideas
- Single Blocks - Allow for single cell collision blocks
- bosses every X levels

## todo list
- next level screen
- game over screen
