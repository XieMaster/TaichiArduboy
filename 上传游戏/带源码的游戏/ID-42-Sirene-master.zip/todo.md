## Sirène

- ~~fix trident~~
- ~~fix bubbles~~
- ~~fix seaShell~~
- ~~fix magic~~
- ~~we need some kind of charger (small line, circle parts, sparkling effect)~~
- add damage to all weapons 

- ~~add HUD score~~
- ~~add HUD life~~


- all possible background mockups
- enemies (design, ~~info~~, ~~sprites~~)

- describe enemy waves
