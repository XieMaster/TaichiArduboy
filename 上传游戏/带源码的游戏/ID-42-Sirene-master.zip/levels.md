##PART 1
{ //STAGE 1
  wave001,
  wave001,
  wave002,
  wave101, //POWER_UP_SHIELD
  wave003,
  wave005,
  wave005,
  wave106, //POWER_UP_STAR
  wave001,
  wave002,
  wave001,
  wave103, //POWER_UP_BUBBLE
  wave002,
  wave003,
  wave004,
  wave106, //POWER_UP_STAR
  wave004,
  wave001,
  wave005,
  wave100, //POWER_UP_HEART
  wave005,
  wave001,
  wave007,
  wave000,
  wave254,
},
{ //STAGE 2
  wave001,
  wave001,
  wave002,
  wave104, //POWER_UP_SEASHELL
  wave002,
  wave003,
  wave001,
  wave106, //POWER_UP_STAR
  wave002,
  wave002,
  wave003,
  wave101, //POWER_UP_SHIELD
  wave003,
  wave004,
  wave007,
  wave106, //POWER_UP_STAR
  wave007,
  wave005,
  wave006,
  wave100, //POWER_UP_HEART
  wave005,
  wave006,
  wave007,
  wave000,
  wave254,
},
{ //STAGE 3
  wave010,
  wave009,
  wave008,
  wave101, //POWER_UP_SHIELD
  wave006,
  wave005,
  wave011,
  wave106, //POWER_UP_STAR
  wave011,
  wave005,
  wave006,
  wave100, //POWER_UP_HEART
  wave008,
  wave009,
  wave010,
  wave106, //POWER_UP_STAR
  wave009,
  wave006,
  wave005,
  wave103, //POWER_UP_BUBBLE
  wave005,
  wave011,
  wave250,
  wave000,
  wave254,
},

##PART 2
{ //STAGE 4
  wave012,
  wave001,
  wave012,
  wave100, //POWER_UP_HEART
  wave001,
  wave013,
  wave002,
  wave106, //POWER_UP_STAR
  wave013,
  wave001,
  wave012,
  wave105, //POWER_UP_MAGIC
  wave001,
  wave013,
  wave007,
  wave106, //POWER_UP_STAR
  wave011,
  wave010,
  wave013,
  wave102, //POWER_UP_TRIDENT
  wave007,
  wave012,
  wave001,
  wave000,
  wave254,
},
{ //STAGE 5
  wave015,
  wave015,
  wave014,
  wave104, //POWER_UP_SEASHELL
  wave013,
  wave006,
  wave005,
  wave106, //POWER_UP_STAR
  wave006,
  wave010,
  wave015,
  wave101, //POWER_UP_SHIELD
  wave014,
  wave013,
  wave013,
  wave106, //POWER_UP_STAR
  wave009,
  wave008,
  wave006,
  wave100, //POWER_UP_HEART
  wave015,
  wave014,
  wave013,
  wave000,
  wave254,
},
{ //STAGE 6
  wave001,
  wave002,
  wave003,
  wave100, //POWER_UP_HEART
  wave004,
  wave005,
  wave006,
  wave106, //POWER_UP_STAR
  wave007,
  wave008,
  wave009,
  wave103, //POWER_UP_BUBBLE
  wave010,
  wave011,
  wave012,
  wave106, //POWER_UP_STAR
  wave013,
  wave014,
  wave015,
  wave102, //POWER_UP_TRIDENT
  wave014,
  wave013,
  wave251,
  wave000,
  wave254,
},

##PART 3
{ //STAGE 7
  wave012,
  wave013,
  wave012,
  wave100, //POWER_UP_HEART
  wave010,
  wave016,
  wave013,
  wave106, //POWER_UP_STAR
  wave012,
  wave010,
  wave011,
  wave105, //POWER_UP_MAGIC
  wave011,
  wave007,
  wave016,
  wave106, //POWER_UP_STAR
  wave011,
  wave010,
  wave013,
  wave101, //POWER_UP_SHIELD
  wave007,
  wave012,
  wave001,
  wave000,
  wave254,
},
{ //STAGE 8
  wave007,
  wave014,
  wave017,
  wave104, //POWER_UP_SEASHELL
  wave016,
  wave003,
  wave001,
  wave106, //POWER_UP_STAR
  wave013,
  wave012,
  wave003,
  wave100, //POWER_UP_HEART
  wave016,
  wave017,
  wave016,
  wave106, //POWER_UP_STAR
  wave007,
  wave005,
  wave010,
  wave105, //POWER_UP_MAGIC
  wave009,
  wave006,
  wave007,
  wave000,
  wave254,
},
{ //STAGE 9
  wave016,
  wave017,
  wave018,
  wave102, //POWER_UP_TRIDENT
  wave004,
  wave005,
  wave006,
  wave106, //POWER_UP_STAR
  wave007,
  wave008,
  wave016,
  wave100, //POWER_UP_HEART
  wave017,
  wave018,
  wave012,
  wave106, //POWER_UP_STAR
  wave013,
  wave014,
  wave015,
  wave100, //POWER_UP_HEART
  wave016,
  wave017,
  wave018,
  wave252,
  wave255,
},