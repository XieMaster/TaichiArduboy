# Epic Crates Of Mass Destruction 
![Image](http://www.team-arg.org/masterfiles/team-arg-ecomd/images/banner-ID-33.png)

EPIC CRATES OF MASS DESTRUCTION : http://www.team-arg.org/ecomd-manual.html  

**Download latest Arduboy version and source :** https://github.com/TEAMarg/ID-33-ECOMD/releases/latest  

MADE by TEAM a.r.g. : http://www.team-arg.org/more-about.html

2015 - DRAGULA96 - JO3RI  (Firepit animation by @JUSTIN_CYR)

Thanks to MLXXXp for his help on switching from ARGlib to the Arduboy 2 library

Game License: MIT : https://opensource.org/licenses/MIT
